from arithmetic_arranger import arithmetic_arranger

# Example usage:
problems = ["32 + 698", "3801 - 2", "45 + 43", "123 + 49"]
arranged_problems = arithmetic_arranger(problems)
print(arranged_problems)

# You can also test with answers displayed:
# arranged_problems_with_answers = arithmetic_arranger(problems, show_answers=True)
# print(arranged_problems_with_answers)
